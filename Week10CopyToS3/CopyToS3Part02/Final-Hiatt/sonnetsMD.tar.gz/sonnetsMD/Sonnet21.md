
# SONNET 21

## William Shakespeare

--------

    So is it not with me as with that Muse,
    Stirr'd by a painted beauty to his verse;
    Who heaven itself for ornament doth use, 
    And every fair with his fair doth rehearse; 
    Making a couplement of proud compare, 
    With sun and moon, with earth and sea's rich gems,
    With April's first-born flowers, and all things rare 
    That heaven's air in this huge rondure hems. 
    O' let me, true in love, but truly write, 
    And then believe me, my love is as fair 
    As any mother's child, though not so bright 
    As those gold candles fix'd in heaven's air: 
       Let them say more than like of hearsay well;
       I will not praise, that purpose not to sell. 

> Written with [StackEdit](https://stackedit.io/).