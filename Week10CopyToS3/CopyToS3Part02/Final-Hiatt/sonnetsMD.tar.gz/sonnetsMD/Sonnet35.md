
# SONNET 35

## William Shakespeare

------

    No more be griev'd at that which thou hast done:
    Roses have thorns, and silver fountains mud, 
    Clouds and eclipses stain both moon and sun, 
    And loathsome canker lives in sweetest bud. 
    All men make faults, and even I in this, 
    Authorizing thy trespass with compare, 
    Myself corrupting, salving thy amiss, 
    Excusing thy sins more than thy sins are; 
    For to thy sensual fault I bring in sense, 
    (Thy adverse party is thy advocate) 
    And 'gainst myself a lawful plea commence:
    Such civil war is in my love and hate 
    That I an accessary needs must be 
    To that sweet thief which sourly robs from me. 

> Written with [StackEdit](https://stackedit.io/).