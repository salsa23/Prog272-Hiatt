
# SONNET 9

## William Shakespeare
-----
    
    Is it for fear to wet a widow's eye 
    That thou consumest thyself in single life?
    Ah! if thou issueless shalt hap to die, 
    The world will wail thee, like a makeless wife;
    The world will be thy widow and still weep 
    That thou no form of thee hast left behind, 
    When every private widow well may keep 
    By children's eyes her husband's shape in mind.
    Look what an unthrift in the world doth spend 
    Shifts but his place, for still the world enjoys it;
    But beauty's waste hath in the world an end, 
    And kept unused, the user so destroys it. 
        No love toward others in that bosom sits 
        That on himself such murderous shame commits.


> Written with [StackEdit](https://stackedit.io/).