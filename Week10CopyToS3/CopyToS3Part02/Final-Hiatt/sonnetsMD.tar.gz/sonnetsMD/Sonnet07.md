
# SONNET 7

## William Shakespeare
-------------
    
    Lo, in the orient when the gracious light 
    Lifts up his burning head, each under eye 
    Doth homage to his new-appearing sight, 
    Serving with looks his sacred majesty; 
    And having climb'd the steep-up heavenly hill,
    Resembling strong youth in his middle age, 
    yet mortal looks adore his beauty still, 
    Attending on his golden pilgrimage; 
    But when from high-most pitch, with weary car,
    Like feeble age, he reeleth from the day, 
    The eyes, 'fore duteous, now converted are 
    From his low tract and look another way: 
        So thou, thyself outgoing in thy noon, 
        Unlook'd on diest, unless thou get a son.

> Written with [StackEdit](https://stackedit.io/).