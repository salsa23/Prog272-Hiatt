
# SONNET 11

## William Shakespeare
-----

    As fast as thou shalt wane, so fast thou growest
    In one of thine, from that which thou departest;
    And that fresh blood which youngly thou bestow'st 
    Thou mayst call thine when thou from youth convertest.
    Herein lives wisdom, beauty and increase: 
    Without this, folly, age and cold decay: 
    If all were minded so, the times should cease
    And threescore year would make the world away. 
    Let those whom Nature hath not made for store, 
    Harsh featureless and rude, barrenly perish: 
    Look, whom she best endow'd she gave the more; 
    Which bounteous gift thou shouldst in bounty cherish:
       She carved thee for her seal, and meant thereby 
       Thou shouldst print more, not let that copy die. 

> Written with [StackEdit](https://stackedit.io/).