
# SONNET 17

## William Shakespeare
-----

    Who will believe my verse in time to come,
    If it were fill'd with your most high deserts?
    Though yet Heaven knows it is but as a tomb 
    Which hides your life and shows not half your parts.
    If I could write the beauty of your eyes, 
    And in fresh numbers number all your graces, 
    The age to come would say, 'This poet lies, 
    Such heavenly touches ne'er touch'd earthly faces.'
    So should my papers yellow'd with their age, 
    Be scorn'd like old men of less truth than tongue,
    And your true rights be term'd a poet's rage 
    And stretched metre of an antique song: 
       But were some child of yours alive that time,
       You should live twice,-- in it and in my rhyme. 

> Written with [StackEdit](https://stackedit.io/).