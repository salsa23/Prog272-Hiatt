
# SONNET 33

## William Shakespeare

-----

    Full many a glorious morning have I seen 
    Flatter the mountain-tops with sovereign eye,
    Kissing with golden face the meadows green, 
    Gilding pale streams with heavenly alchemy; 
    Anon permit the basest clouds to ride 
    With ugly rack on his celestial face, 
    And from the forlorn world his visage hide,
    Stealing unseen to west with this disgrace:
    Even so my sun one early morn did shine 
    With all triumphant splendor on my brow; 
    But out! alack! he was but one hour mine, 
    The region cloud hath mask'd him from me now. 
    Yet him for this my love no whit disdaineth; 
    Suns of the world may stain when heaven's sun staineth. 

> Written with [StackEdit](https://stackedit.io/).