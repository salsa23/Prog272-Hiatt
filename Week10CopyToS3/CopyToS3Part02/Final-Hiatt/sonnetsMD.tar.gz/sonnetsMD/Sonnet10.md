
# SONNET 10

## William Shakespeare
-----

    For shame deny that thou bear'st love to any,
    Who for thyself art so unprovident. 
    Grant, if thou wilt, thou art beloved of many,
    But that thou none lovest is most evident; 
    For thou art so possess'd with murderous hate 
    That 'gainst thyself thou stick'st not to conspire.
    Seeking that beauteous roof to ruinate 
    Which to repair should be thy chief desire.
    O, change thy thought, that I may change my mind!
    Shall hate be fairer lodged than gentle love? 
    Be, as thy presence is, gracious and kind, 
    Or to thyself at least kind-hearted prove: 
        Make thee another self, for love of me,
        That beauty still may live in thine or thee.


> Written with [StackEdit](https://stackedit.io/).