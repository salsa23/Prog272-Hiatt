
# SONNET 23

## William Shakespeare
-------

    As an unperfect actor on the stage, 
    Who with his fear is put besides his part,
    Or some fierce thing replete with too much rage,
    Whose strength's abundance weakens his own heart; 
    So I, for fear of trust, forget to say 
    The perfect ceremony of love's rite, 
    And in mine own love's strength seem to decay,
    O'ercharg'd with burden of mine own love's might. 
    O let my books be then the eloquence 
    And dumb presagers of my speaking breast, 
    Who plead for love and look for recompense 
    More than that tongue that more hath more express'd.
       O, learn to read what silent love hath writ: 
       To hear with eyes belongs to love's fine wit. 

> Written with [StackEdit](https://stackedit.io/).