
# SONNET 34

## William Shakespeare

------

    Why didst thou promise such a beauteous day,
    And make me travel forth without my cloak, 
    To let base clouds o'ertake me in my way, 
    Hiding thy bravery in their rotten smoke? 
    'Tis not enough that through the cloud thou break,
    To dry the rain on my storm-beaten face, 
    For no man well of such a salve can speak 
    That heals the wound and cures not the disgrace:
    Nor can thy shame give physic to my grief; 
    Though thou repent, yet I have still the loss: 
    The offender's sorrow lends but weak relief 
    To him that bears the strong offence's [cross]. 
       Ah! but those tears are pearl which thy love sheds,
       And they are rich and ransom all ill deeds. 

> Written with [StackEdit](https://stackedit.io/).