
# SONNET 26

## William Shakespeare

-----

    Lord of my love, to whom in vassalage 
    Thy merit hath my duty strongly knit, 
    To thee I send this written ambassage, 
    To witness duty, not to show my wit. 
    Duty so great, which wit so poor as mine 
    May make seem bare, in wanting words to show it,
    But that I hope some good conceit of thine 
    In thy soul's thought, all naked, will bestow it:
    Till whatsoever star that guides my moving, 
    Points on me graciously with fair aspect, 
    And puts apparel on my tattered loving, 
    To show me worthy of thy sweet respect: 
       Then may I dare to boast how I do love thee,
       Till then not show my head where thou may'st prove me. 

> Written with [StackEdit](https://stackedit.io/).