
# SONNET 4

## William Shakespeare

---------------------------------------

    Unthrifty loveliness, why dost thou spend 
    Upon thyself thy beauty's legacy? 
    Nature's bequest gives nothing but doth lend,
    And being frank, she lends to those are free. 
    Then, beauteous niggard, why dost thou abuse 
    The bounteous largess given thee to give? 
    Profitless usurer, why dost thou use 
    So great a sum of sums, yet canst not live?
    For having traffic with thyself alone, 
    Thou of thyself thy sweet self dost deceive.
    Then how, when Nature calls thee to be gone, 
    What acceptable audit canst thou leave? 
    Thy unused beauty must be tomb'd with thee, 
    Which, used, lives th' executor to be. 


> Written with [StackEdit](https://stackedit.io/).