
# SONNET 3

## William Shakespeare

------------------------------

    Look in thy glass, and tell the face thou viewest 
    Now is the time that face should form another; 
    Whose fresh repair if now thou not renewest, 
    Thou dost beguile the world, unbless some mother,
    For where is she so fair whose unear'd womb 
    Disdains the tillage of thy husbandry? 
    Or who is he so fond will be the tomb 
    Of his self-love, to stop posterity? 
    Thou art thy mother's glass, and she in thee
    Calls back the lovely April of her prime: 
    So thou through windows of thine age shall see
    Despite of wrinkles this thy golden time. 
    But if thou live, remember'd not to be, 
    Die single, and thine image dies with thee.


> Written with [StackEdit](https://stackedit.io/).