
# SONNET 32

## William Shakespeare

-----

    If thou survive my well-contented day, 
    When that churl Death my bones with dust shall cover,
    And shalt by fortune once more re-survey 
    These poor rude lines of thy deceased lover, 
    Compare them with the bettering of the time, 
    And though they be outstripp'd by every pen, 
    Reserve them for my love, not for their rhyme, 
    Exceeded by the height of happier men. 
    O, then vouchsafe me but this loving thought:
    'Had my friend's Muse grown with this growing age,
    A dearer birth than this his love had brought, 
    To march in ranks of better equipage: 
       But since he died, and poets better prove,
       Theirs for their style I'll read, his for his love.' 

> Written with [StackEdit](https://stackedit.io/).